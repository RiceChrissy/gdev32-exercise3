#version 330 core

void main()
{
}
